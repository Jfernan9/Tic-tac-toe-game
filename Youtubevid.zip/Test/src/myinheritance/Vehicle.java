package myinheritance;

public class Vehicle {
    protected String brand = "Ford";        // Vehicle attribute

    public void honk()  // Vehicle method
    {
        System.out.println("Tuut, tuut!");
    }

}
