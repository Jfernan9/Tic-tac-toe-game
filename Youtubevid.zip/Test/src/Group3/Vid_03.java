package Group3;

import java.util.InputMismatchException;
import java.util.Scanner;

public class Vid_03
{
    public static void main(String[] args)
    {
        Scanner keyboard = new Scanner(System.in);
        try
        {
            int [] array = {2};
            array[4] = 7;
            System.out.println("Enter a number.");
            int x = keyboard.nextInt();

            System.out.println("Enter another number");
            int y = keyboard.nextInt();

            System.out.println("The value of " + x+ "/" + y+ "is" + (x/y));

        }
        catch (InputMismatchException e) {
            System.out.println("You entered an invalid integer");
        }
        catch (ArithmeticException e)
        {
            System.out.println("You cannot divide by zero");

        }
        catch (Throwable e )
        {
            System.out.println("Some other issue happened");
        }

    }
}
