package Group3;

public class Vid_01_Part2
{
    public static void main(String[] args)
    {
        int [] array ={2,5,7,12,50,23};

        for (int i = 0; i<=array.length; i ++)
        {
            System.out.println(array[i]);

        }
        System.out.println("The end");

    }
}
