package Group3;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
public class Vid_06
{
    public static void main(String[] args)
    {
        PrintWriter pw = null;

        try {
             pw = new PrintWriter("myfile.txt");
            pw.println("Hello World");

        } catch (FileNotFoundException e) {
            System.out.println(e.getMessage());

        }
        finally {
            pw.close();
        }



    }












    }




