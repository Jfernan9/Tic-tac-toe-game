public class Exercise_01_09
{
    public static void main(String[] args)
    {
        System.out.println("Area = ");
        System.out.println(4.5 * 7.9);
        System.out.println("Perimeter = ");
        System.out.println((4.5 + 7.9) * 2);



    }
}
