package myArrayOfObjects;

public class PersonsTwoUserInputImpl
{
    public static void main(String[] args)
    {


    }

}
