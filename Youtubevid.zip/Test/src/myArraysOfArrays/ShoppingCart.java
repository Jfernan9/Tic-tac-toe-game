package myArraysOfArrays;

import java.util.ArrayList;

public class ShoppingCart {
    public static void main(String[] args) {
        ArrayList<String> ShoppingCart = new ArrayList<String>();
        ShoppingCart.add("Jeans");
        ShoppingCart.add("T-shirt");
        ShoppingCart.add("Shoes");
        ShoppingCart.add("Socks");
        System.out.println(ShoppingCart);


    }

    public static void add(String jeans) {
    }
}
