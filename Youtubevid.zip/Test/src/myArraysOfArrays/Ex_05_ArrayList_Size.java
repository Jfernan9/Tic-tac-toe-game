package myArraysOfArrays;

import java.util.ArrayList;

public class Ex_05_ArrayList_Size {
    public static <Arraylist> void main(String[] args) {
        ArrayList<String> Shoppingcart = new ArrayList<String>();
        ShoppingCart.add("Jeans");
        ShoppingCart.add("T-shirt");
        ShoppingCart.add("Shoes");
        ShoppingCart.add("Socks");
        System.out.println(Shoppingcart.size());


}

}
