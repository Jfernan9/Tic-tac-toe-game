public class Exercise_01_10
{
    public static void main(String[] args)
    {
        System.out.println((14 / 45.30) / 1.6);
    }

}



