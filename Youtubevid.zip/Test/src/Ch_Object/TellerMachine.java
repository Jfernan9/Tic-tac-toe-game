package Ch_Object;

public class TellerMachine
{
    public static void main(String [] args){
        int choose = 1 ;
                switch (choose) {
                    case 1:
                        System.out.println("Withdraw 50000");
                        break;
                    case 2:
                        System.out.println("Deposit");
                        System.out.println("Please ");
                    case 3:
                        System.out.println("Check for you balance");
                    case 4:
                        System.out.println("Exit");

                }
    }
}
