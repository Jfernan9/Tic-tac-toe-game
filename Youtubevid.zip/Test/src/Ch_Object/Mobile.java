package Ch_Object;

public class Mobile
{
    String brand, color;
    int camera;

    /// Constructor initialized
    public Mobile(String brand, String color, int camera)
    {
        this.brand = brand;
        this.color = color;
        this.camera = camera;


    }

}
