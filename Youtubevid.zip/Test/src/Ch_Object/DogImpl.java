package Ch_Object;

public class DogImpl
{
    public static void main(String[] args){

        Dog tuffy = new Dog( "tuffy" ," papillion", 5, "white");
        System.out.println(tuffy.toString());
    }



}
