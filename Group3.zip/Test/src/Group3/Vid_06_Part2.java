package Group3;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.Scanner;

public class Vid_06_Part2
{
    public static  void main(String[] args) {


        File f = new File("myfile.txt");
        Scanner fs = null;
        try {

             fs = new Scanner(f);
            System.out.println(fs.nextLine());
        } catch (FileNotFoundException e) {
            System.out.println(e.getMessage());
        }
        finally {
            if(fs!=null)
            fs.close();
        }



    }

        }



