package Group3;

public class Vid_01
{
    public static void main(String[] args)
    {
        int x = 5;
        int y = 0;

        System.out.println(x/y);
        System.out.println("the end");


    }
}
