package Ch_Object;

public class Personimpl {
    public static void main(String[] args)
    {


                Person mike = new Person( "mike", 22, 100, 100);
        System.out.print(mike.toString());

    }
}
