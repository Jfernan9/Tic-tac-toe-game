package Ch_Object;

public class ClassInJava {

    String name;
    int rollno;
    String fathername;
    String contactno;
    String address;

    //Constructor

    ClassInJava(String name, int rollno, String fathername, String contactno, String address) {

        this.name=name;
        this.rollno=rollno;
        this.contactno=contactno;
        this.address=address;

    }
}
