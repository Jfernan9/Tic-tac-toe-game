public class Exercise_01_08
{
    public static void main(String[] args)
    {
        System.out.println("Perimeter = ");
        System.out.println(2 * 5.5 * 3.14159);
        System.out.println("Area");
        System.out.println(5.5 * 5.5 * 3.14159);


    }
}
