public class Welcome
{
    public static void main(String[] arg)
    {
        System.out.println("Welcome to java!");

    }
}
