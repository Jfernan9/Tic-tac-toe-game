public class Exercise_01_01
{
    public static void main(String[] args)
    {
        System.out.println("Welcome to Java");
        System.out.println("Welcome to Computer Science");
        System.out.println("Programming is fun");
        System.out.println("J   A  V  V   A");

    }



}
