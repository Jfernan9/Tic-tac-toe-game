package MyExceptions;

public class Exceptions_01 {

    public static void main(String[] args) {
        int [] myNumbers={1,2,3};
        System.out.println(myNumbers[0]);
        System.out.println(myNumbers[1]);
        System.out.println(myNumbers[2]);
        System.out.println(myNumbers[3]);


    }
}
