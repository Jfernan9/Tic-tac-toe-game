package Group_03;

public class StringContainsOnlyIntegers
{
    public static void main(String[] args)
    {
        String x = "97BCD";
        char y[] = x.toCharArray();
        int size = y.length;

        int i=0;
        while(i != size)
        {
            if(y[i] >= '0' && y[i] <= '9' )
            {
                ++i;
            }
            else
            {
                System.out.println("Not an Integer String");
                System.exit(0);

            }
        }
        System.out.println("Integer String");
    }

}
