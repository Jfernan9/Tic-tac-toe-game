package Group_03;

public class HowToCountVowels
{
    public static void main(String[] args)
    {
        String x = "ARADHYA'S BRILLIANCE CENTER";

        char y [] = x.toCharArray();
        int size = y.length;
        int vowcnt = 0;
        int conscnt = 0;
        int splcnt =0;

        int i =0;
        while ( i!=size)

        {
            if(y[i]>='A' && y[i]<='z')
            {
                if(y[i]=='A'|| y[i]=='E'|| y[i]=='I'||y[i]=='O'|| y[i]=='U' )
                {
                 ++vowcnt;
                }
                else
                {
                    ++conscnt;
                }
            }
            else
            {
                ++splcnt;

            }
            ++i;

        }
        System.out.println(y);
        System.out.println("vowel count="+vowcnt);
        System.out.println("consonant count="+conscnt);
        System.out.println("special characters count="+splcnt);

    }
}
