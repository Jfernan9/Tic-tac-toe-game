package Group_03;

import java.util.Arrays;

public class AnagramProgram
{
    public static void main(String[] args)
    {
        String x = "ARADYA";
        String y = "RADAYA";

        char a[] = x.toCharArray();
        char b[] = y.toCharArray();

        Arrays.sort(a);
        Arrays.sort(b);

        boolean result = Arrays.equals(a,b);

        if(result == true)
        {
            System.out.println("String are Anagram");

        }
        else
        {
            System.out.println("Strings are not Anagram");
        }



    }

}
