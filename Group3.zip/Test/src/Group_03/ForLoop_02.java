package Group_03;

public class ForLoop_02
{
    public static void main(String[] args) {
        double a[] = {10.5,20.63,30.08,40.92,50.73};
        double sum = 0.0;
        for (double data : a)
        {
            sum = sum +data;
        }
        System.out.println(sum);
    }
}
