package Group_03;

public class ComputingLengthOfString
{
    public static void main(String[] args)
    {
        String x = "ABC tech";
        x = x.concat("\0");
        char y[] = x.toCharArray();

        int count=0;
        int i=0;
        while(y[i] !='\0')
        {
            ++count;
            ++i;
        }
        System.out.printf("%d", count);

        // Other way of running this code would like this
        // Class Demo{
        // public static void main(String[] args){
        // String x = "ABC tech";
        // System.out.printf("%d", x.length());
    }
}
