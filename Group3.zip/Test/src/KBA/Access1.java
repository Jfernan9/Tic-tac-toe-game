package KBA;

public class Access1
{
    public int hours =3;
  public int minutes = 47;

}
