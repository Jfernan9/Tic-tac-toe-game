package myArraysOfArrays;
import java.util.ArrayList;


public class Ex_01_Add_Items {

    public static void main(String[] args) {
        ArrayList<String> cars = new ArrayList<String>();
        cars.add("Volvo");
        cars.add("BMW");
        cars.add("Ford");
        cars.add("Mazda");
        cars.add("VW");
        System.out.println(cars);


    }
}
